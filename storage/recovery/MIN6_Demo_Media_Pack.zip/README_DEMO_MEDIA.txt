MIN SIX - Demo Media Pack
=========================
Sumber utama:
- PDF internal MIN 6 Jember 2026 (Sosialisasi RA_20260205_152158_0000.pdf)
- Foto GTK dipotong dari halaman profil GTK pada PDF sumber.
- Foto kegiatan diekstrak dari aset gambar di PDF sumber.
- Poster SPMB dan QR berasal dari halaman SPMB PDF sumber.

Cara pasang:
1. Ekstrak isi ZIP ini ke ROOT proyek MIN SIX.
2. Pastikan folder berikut terbentuk:
   uploads/demo/activities/
   uploads/demo/gtk/
3. Import SQL:
   database/upgrades/20261002_initial_content_seed.sql
   atau file seed yang disertakan bersama pack.
4. Buka website dan ganti foto demo melalui Media/CMS bila sudah tersedia foto resmi resolusi lebih baik.

Catatan:
- Konten berjudul [DEMO] adalah mockup, bukan berita/agenda/prestasi resmi.
- Data identitas/history yang berasal dari website lama perlu verifikasi operator sebelum production.
- Foto GTK dari PDF dipakai sebagai data awal, bukan standar foto final.
