-- MIN SIX DEMO/INITIAL CONTENT SEED
-- Target: database localhost dump 02 Oct 2026 (PHASE 8 schema)
-- Source priority:
-- 1) PDF internal MIN 6 Jember 2026: Sosialisasi RA_20260205_152158_0000.pdf
-- 2) Data yang sudah ada pada dump localhost
-- 3) Website resmi/arsip min6jember.sch.id (profil, sejarah, berita lama)
-- 4) Data DEMO diberi penanda [DEMO] pada judul/isi agar tidak dianggap fakta produksi
-- Demo media harus diekstrak ke ROOT proyek sehingga path uploads/demo/... tersedia.

SET NAMES utf8mb4;
START TRANSACTION;

-- -----------------------------------------------------------------
-- MEDIA PACK
-- -----------------------------------------------------------------
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('achievement.jpg', 'achievement.jpg', 'uploads/demo/activities/achievement.jpg', 'image/jpeg', 'jpg', 55942, 506, 900, 'Prestasi peserta didik MIN 6 Jember', 'Dokumentasi prestasi peserta didik dari PDF sumber.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('ceremony.jpg', 'ceremony.jpg', 'uploads/demo/activities/ceremony.jpg', 'image/jpeg', 'jpg', 204140, 1200, 675, 'Upacara bendera di halaman MIN 6 Jember', 'Dokumentasi pembiasaan upacara bendera Senin pagi dari PDF sumber.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('classroom.jpg', 'classroom.jpg', 'uploads/demo/activities/classroom.jpg', 'image/jpeg', 'jpg', 88735, 1200, 563, 'Kegiatan pembelajaran di kelas MIN 6 Jember', 'Dokumentasi kegiatan pembelajaran kelas dari PDF sumber.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('extracurricular.jpg', 'extracurricular.jpg', 'uploads/demo/activities/extracurricular.jpg', 'image/jpeg', 'jpg', 203808, 1200, 900, 'Kegiatan ekstrakurikuler dan prestasi MIN 6 Jember', 'Dokumentasi ekstrakurikuler dari PDF sumber.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('hero_welcome.jpg', 'hero_welcome.jpg', 'uploads/demo/activities/hero_welcome.jpg', 'image/jpeg', 'jpg', 240139, 1200, 900, 'Sambut siswa pagi di MIN 6 Jember', 'Dokumentasi sambut siswa setiap pagi dari PDF sumber MIN 6 Jember.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('religious.jpg', 'religious.jpg', 'uploads/demo/activities/religious.jpg', 'image/jpeg', 'jpg', 107418, 1200, 540, 'Pembiasaan keagamaan peserta didik MIN 6 Jember', 'Dokumentasi pembiasaan keagamaan harian dari PDF sumber.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('spmb_poster.jpg', 'spmb_poster.jpg', 'uploads/demo/activities/spmb_poster.jpg', 'image/jpeg', 'jpg', 125025, 636, 900, 'Poster SPMB MIN 6 Jember Tahun Ajaran 2026/2027', 'Poster penerimaan murid baru madrasah dari PDF sumber.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('spmb_qr.jpg', 'spmb_qr.jpg', 'uploads/demo/activities/spmb_qr.jpg', 'image/jpeg', 'jpg', 26256, 350, 350, 'QR pendaftaran SPMB MIN 6 Jember 2026/2027', 'Potongan QR pendaftaran dari poster SPMB sumber.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('spmb_wide.jpg', 'spmb_wide.jpg', 'uploads/demo/activities/spmb_wide.jpg', 'image/jpeg', 'jpg', 167150, 1200, 600, 'Informasi SPMB dan prestasi MIN 6 Jember 2026/2027', 'Poster informasi SPMB dan prestasi dari PDF sumber.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('yanbua.jpg', 'yanbua.jpg', 'uploads/demo/activities/yanbua.jpg', 'image/jpeg', 'jpg', 178099, 1198, 900, 'Pembelajaran Al-Qur''an metode Yanbu''a', 'Dokumentasi pembelajaran Al-Qur''an metode Yanbu''a dari PDF sumber.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('abdul-hamid.jpg', 'abdul-hamid.jpg', 'uploads/demo/gtk/abdul-hamid.jpg', 'image/jpeg', 'jpg', 16681, 360, 450, 'Foto Abdul Hamid - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('agus-kiki-susanto.jpg', 'agus-kiki-susanto.jpg', 'uploads/demo/gtk/agus-kiki-susanto.jpg', 'image/jpeg', 'jpg', 15793, 360, 450, 'Foto Agus Kiki Susanto - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('ari-prasetyaningtias.jpg', 'ari-prasetyaningtias.jpg', 'uploads/demo/gtk/ari-prasetyaningtias.jpg', 'image/jpeg', 'jpg', 16864, 360, 450, 'Foto Ari Prasetyaningtias - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('badruttamam.jpg', 'badruttamam.jpg', 'uploads/demo/gtk/badruttamam.jpg', 'image/jpeg', 'jpg', 16156, 360, 450, 'Foto Badruttamam - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('dodik-agung-dermawan.jpg', 'dodik-agung-dermawan.jpg', 'uploads/demo/gtk/dodik-agung-dermawan.jpg', 'image/jpeg', 'jpg', 16425, 360, 450, 'Foto Dodik Agung Dermawan - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('eko-iswanto.jpg', 'eko-iswanto.jpg', 'uploads/demo/gtk/eko-iswanto.jpg', 'image/jpeg', 'jpg', 15962, 360, 450, 'Foto Eko Iswanto - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('fitriyani-purwanti.jpg', 'fitriyani-purwanti.jpg', 'uploads/demo/gtk/fitriyani-purwanti.jpg', 'image/jpeg', 'jpg', 16625, 360, 450, 'Foto Fitriyani Purwanti - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('ishaq-kholilur-rohman.jpg', 'ishaq-kholilur-rohman.jpg', 'uploads/demo/gtk/ishaq-kholilur-rohman.jpg', 'image/jpeg', 'jpg', 15153, 360, 450, 'Foto Ishaq Kholilur Rohman - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('isnainul-arifin.jpg', 'isnainul-arifin.jpg', 'uploads/demo/gtk/isnainul-arifin.jpg', 'image/jpeg', 'jpg', 15394, 360, 450, 'Foto Isnainul Arifin - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('kholifah.jpg', 'kholifah.jpg', 'uploads/demo/gtk/kholifah.jpg', 'image/jpeg', 'jpg', 16696, 360, 450, 'Foto Kholifah - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('lutfi-handayani.jpg', 'lutfi-handayani.jpg', 'uploads/demo/gtk/lutfi-handayani.jpg', 'image/jpeg', 'jpg', 16311, 360, 450, 'Foto Lutfi Handayani - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('m-zayyinul-furqon.jpg', 'm-zayyinul-furqon.jpg', 'uploads/demo/gtk/m-zayyinul-furqon.jpg', 'image/jpeg', 'jpg', 16426, 360, 450, 'Foto M. Zayyinul Furqon - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('mamik-nurhakim.jpg', 'mamik-nurhakim.jpg', 'uploads/demo/gtk/mamik-nurhakim.jpg', 'image/jpeg', 'jpg', 16369, 360, 450, 'Foto Mamik Nurhakim - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('muhammad-ismail-wahyuda.jpg', 'muhammad-ismail-wahyuda.jpg', 'uploads/demo/gtk/muhammad-ismail-wahyuda.jpg', 'image/jpeg', 'jpg', 16015, 360, 450, 'Foto Muhammad Ismail Wahyuda - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('naely-hanik-rz.jpg', 'naely-hanik-rz.jpg', 'uploads/demo/gtk/naely-hanik-rz.jpg', 'image/jpeg', 'jpg', 16901, 360, 450, 'Foto Naely Hanik Rz - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('nur-hayati.jpg', 'nur-hayati.jpg', 'uploads/demo/gtk/nur-hayati.jpg', 'image/jpeg', 'jpg', 17250, 360, 450, 'Foto Nur Hayati - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('pangestika-wisnu-murti.jpg', 'pangestika-wisnu-murti.jpg', 'uploads/demo/gtk/pangestika-wisnu-murti.jpg', 'image/jpeg', 'jpg', 16283, 360, 450, 'Foto Pangestika Wisnu Murti - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('ribut-setianingsih.jpg', 'ribut-setianingsih.jpg', 'uploads/demo/gtk/ribut-setianingsih.jpg', 'image/jpeg', 'jpg', 16365, 360, 450, 'Foto Ribut Setianingsih - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('risya-umami-muad.jpg', 'risya-umami-muad.jpg', 'uploads/demo/gtk/risya-umami-muad.jpg', 'image/jpeg', 'jpg', 16424, 360, 450, 'Foto Risya Umami Mu’ad - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('siti-asrofah.jpg', 'siti-asrofah.jpg', 'uploads/demo/gtk/siti-asrofah.jpg', 'image/jpeg', 'jpg', 16866, 360, 450, 'Foto Siti Asrofah - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('sofwana.jpg', 'sofwana.jpg', 'uploads/demo/gtk/sofwana.jpg', 'image/jpeg', 'jpg', 17315, 360, 450, 'Foto Sofwana - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('supangat.jpg', 'supangat.jpg', 'uploads/demo/gtk/supangat.jpg', 'image/jpeg', 'jpg', 15772, 360, 450, 'Foto Supangat - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('susiati.jpg', 'susiati.jpg', 'uploads/demo/gtk/susiati.jpg', 'image/jpeg', 'jpg', 16104, 360, 450, 'Foto Susiati - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('syaifudin-zuhri.jpg', 'syaifudin-zuhri.jpg', 'uploads/demo/gtk/syaifudin-zuhri.jpg', 'image/jpeg', 'jpg', 16570, 360, 450, 'Foto Syaifudin Zuhri - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);
INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('yusnia-khoirunnisa.jpg', 'yusnia-khoirunnisa.jpg', 'uploads/demo/gtk/yusnia-khoirunnisa.jpg', 'image/jpeg', 'jpg', 16186, 360, 450, 'Foto Yusnia Khoirunnisa - MIN 6 Jember', 'Foto sementara diekstrak dari PDF profil MIN 6 Jember; operator dapat mengganti dengan foto resolusi lebih baik.', 'IMAGE', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size), width=VALUES(width), height=VALUES(height);

INSERT INTO media (original_name, stored_name, relative_path, mime_type, extension, file_size, width, height, alt_text, caption, media_type, created_by, created_at)
VALUES ('spmb_2026_2027_poster.pdf', 'spmb_2026_2027_poster.pdf', 'uploads/demo/activities/spmb_2026_2027_poster.pdf', 'application/pdf', 'pdf', 133771, NULL, NULL, 'Brosur SPMB MIN 6 Jember Tahun Ajaran 2026/2027', 'PDF satu halaman dibuat dari poster SPMB pada PDF sumber internal MIN 6 Jember.', 'DOCUMENT', 1, NOW())
ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text), caption=VALUES(caption), file_size=VALUES(file_size);

-- -----------------------------------------------------------------
-- SITE SETTINGS
-- -----------------------------------------------------------------
UPDATE site_settings SET setting_value='MIN 6 Jember', updated_by=1, updated_at=NOW() WHERE setting_key='site_name';
UPDATE site_settings SET setting_value='Berakhlaqul Karimah dan Berprestasi', updated_by=1, updated_at=NOW() WHERE setting_key='site_tagline';
UPDATE site_settings SET setting_value='Jl. Urip Sumoharjo Gg. Legog, Curahbamban, Tanggul Wetan, Kec. Tanggul, Kabupaten Jember, Jawa Timur 68155', updated_by=1, updated_at=NOW() WHERE setting_key='address';
UPDATE site_settings SET setting_value='(0336) 443484', updated_by=1, updated_at=NOW() WHERE setting_key='phone';
UPDATE site_settings SET setting_value='mintanggulwetan@gmail.com', updated_by=1, updated_at=NOW() WHERE setting_key='email';
UPDATE site_settings SET setting_value='min6jember', updated_by=1, updated_at=NOW() WHERE setting_key='instagram_username';
UPDATE site_settings SET setting_value='https://www.instagram.com/min6jember', updated_by=1, updated_at=NOW() WHERE setting_key='instagram_url';
UPDATE site_settings SET setting_value='MIN 6 Jember | Berakhlaqul Karimah dan Berprestasi', updated_by=1, updated_at=NOW() WHERE setting_key='seo_default_title';
UPDATE site_settings SET setting_value='Website resmi MIN 6 Jember, madrasah ibtidaiyah negeri di Tanggul, Jember, dengan pembiasaan keagamaan, pembelajaran, program pengembangan diri, dan prestasi peserta didik.', updated_by=1, updated_at=NOW() WHERE setting_key='seo_default_description';
UPDATE site_settings SET setting_value=(SELECT CAST(id AS CHAR) FROM media WHERE relative_path='uploads/demo/activities/hero_welcome.jpg' LIMIT 1), updated_by=1, updated_at=NOW() WHERE setting_key='seo_default_og_media_id';

-- -----------------------------------------------------------------
-- HOMEPAGE CONTENT
-- -----------------------------------------------------------------
UPDATE homepage_sections SET eyebrow='MADRASAH IBTIDAIYAH NEGERI 6 JEMBER', title='Berakhlaqul Karimah. Tumbuh dalam Prestasi.', subtitle='Madrasah yang menumbuhkan ilmu, karakter, kreativitas, dan nilai-nilai keislaman melalui pembelajaran serta pembiasaan sehari-hari.', body='MIN 6 Jember hadir sebagai ruang belajar dasar yang dekat dengan nilai agama, disiplin, kebersamaan, dan pengalaman belajar yang bermakna.', content_json=NULL, cta_label='Jelajahi Madrasah', cta_url='#mengenal', secondary_cta_label='Kenali MIN 6 Jember', secondary_cta_url='/profil', updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/hero_welcome.jpg' LIMIT 1) WHERE section_key='hero';
UPDATE homepage_sections SET eyebrow='MIN 6 JEMBER', title='Madrasah yang terus tumbuh', subtitle=NULL, body=NULL, content_json='{"items": [{"value": "1997", "label": "Berstatus Negeri"}, {"value": "2017", "label": "Menjadi MIN 6 Jember"}, {"value": "6", "label": "Tingkat Kelas"}, {"value": "19+", "label": "Program & Ekstrakurikuler"}]}', cta_label=NULL, cta_url=NULL, secondary_cta_label=NULL, secondary_cta_url=NULL, updated_by=1, updated_at=NOW() WHERE section_key='stats';
UPDATE homepage_sections SET eyebrow='MENGENAL MIN 6 JEMBER', title='Berakar dari masyarakat, tumbuh sebagai madrasah negeri.', subtitle=NULL, body='MIN 6 Jember berawal dari MI Al Matlabul Ulum yang kemudian dinegerikan pada 1997 sebagai MIN Tanggul Wetan. Sejak 2017, madrasah ini menggunakan nama MIN 6 Jember. Perjalanan tersebut menjadi bagian dari komitmen madrasah untuk terus bertumbuh bersama masyarakat.', content_json=NULL, cta_label='Selengkapnya', cta_url='/profil', secondary_cta_label=NULL, secondary_cta_url=NULL, updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/ceremony.jpg' LIMIT 1) WHERE section_key='about';
UPDATE homepage_sections SET eyebrow='KESEHARIAN MADRASAH', title='Keseharian yang Membentuk Karakter', subtitle=NULL, body='Pembentukan karakter berlangsung melalui kebiasaan sederhana yang dilakukan konsisten: menyambut siswa, upacara, ibadah, doa, membaca Al-Qur''an, dan belajar bersama.', content_json='{"items": ["Sambut siswa setiap pagi", "Upacara bendera hari Senin", "Salat Dhuha", "Pembacaan Asmaul Husna", "Membaca surat-surat pendek", "Membaca doa sebelum belajar", "Salat Zuhur berjamaah", "Pembelajaran Al-Qur''an metode Yanbu''a"]}', cta_label=NULL, cta_url=NULL, secondary_cta_label=NULL, secondary_cta_url=NULL, updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/religious.jpg' LIMIT 1) WHERE section_key='habits';
UPDATE homepage_sections SET eyebrow='BELAJAR & BERKEMBANG', title='Program yang mendampingi setiap proses tumbuh.', subtitle='Akademik, keagamaan, karakter, bahasa, seni, olahraga, dan pengembangan prestasi dirancang sebagai pengalaman belajar yang saling melengkapi.', body=NULL, content_json=NULL, cta_label='Lihat Program', cta_url='/program', secondary_cta_label=NULL, secondary_cta_url=NULL, updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/classroom.jpg' LIMIT 1) WHERE section_key='program_intro';
UPDATE homepage_sections SET eyebrow='PRESTASI PESERTA DIDIK', title='Tumbuh melalui proses, berkembang melalui pengalaman.', subtitle='Prestasi adalah bagian dari proses belajar, keberanian mencoba, dan pembiasaan untuk memberi yang terbaik.', body=NULL, content_json=NULL, cta_label=NULL, cta_url=NULL, secondary_cta_label=NULL, secondary_cta_url=NULL, updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/achievement.jpg' LIMIT 1) WHERE section_key='achievement_intro';
UPDATE homepage_sections SET eyebrow='CERITA DARI MADRASAH', title='Potret keseharian MIN 6 Jember.', subtitle='Dokumentasi pembelajaran, pembiasaan, kegiatan keagamaan, dan ekstrakurikuler.', body=NULL, content_json=NULL, cta_label=NULL, cta_url=NULL, secondary_cta_label=NULL, secondary_cta_url=NULL, updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/extracurricular.jpg' LIMIT 1) WHERE section_key='story_intro';
UPDATE homepage_sections SET eyebrow='KABAR TERBARU', title='Informasi terbaru dari madrasah.', subtitle='Berita, agenda, dan kegiatan MIN 6 Jember.', body=NULL, content_json=NULL, cta_label='Lihat Semua Kabar', cta_url='/kabar', secondary_cta_label=NULL, secondary_cta_url=NULL, updated_by=1, updated_at=NOW() WHERE section_key='news_intro';
UPDATE homepage_sections SET eyebrow='INSTAGRAM', title='Ikuti keseharian @min6jember', subtitle=NULL, body='Dokumentasi singkat kegiatan madrasah melalui kanal Instagram resmi.', content_json=NULL, cta_label=NULL, cta_url=NULL, secondary_cta_label=NULL, secondary_cta_url=NULL, updated_by=1, updated_at=NOW() WHERE section_key='instagram_intro';
UPDATE homepage_sections SET eyebrow='SAMBUTAN KEPALA MADRASAH', title='Bersama menumbuhkan generasi yang berakhlak dan berprestasi.', subtitle=NULL, body='Selamat datang di MIN 6 Jember. Website ini menjadi ruang untuk mengenal madrasah, melihat kegiatan peserta didik, serta mengikuti informasi dan perkembangan madrasah. Semoga setiap langkah pendidikan yang dilakukan bersama keluarga dan masyarakat memberi manfaat bagi tumbuh kembang anak.', content_json=NULL, cta_label='Mengenal Madrasah', cta_url='/profil', secondary_cta_label=NULL, secondary_cta_url=NULL, updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/eko-iswanto.jpg' LIMIT 1) WHERE section_key='headmaster';
UPDATE homepage_sections SET eyebrow='SPMB', title='Mari tumbuh bersama MIN 6 Jember.', subtitle=NULL, body='Informasi penerimaan murid baru Tahun Ajaran 2026/2027 tersedia pada halaman SPMB.', content_json=NULL, cta_label='Informasi SPMB', cta_url='/spmb', secondary_cta_label=NULL, secondary_cta_url=NULL, updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/spmb_wide.jpg' LIMIT 1) WHERE section_key='spmb_cta';
UPDATE homepage_sections SET eyebrow='KONTAK', title='Terhubung dengan MIN 6 Jember', subtitle=NULL, body='Silakan hubungi madrasah melalui kanal resmi untuk informasi akademik, layanan administrasi, dan kegiatan madrasah.', content_json=NULL, cta_label=NULL, cta_url=NULL, secondary_cta_label=NULL, secondary_cta_url=NULL, updated_by=1, updated_at=NOW() WHERE section_key='contact';

-- -----------------------------------------------------------------
-- PROFILE
-- -----------------------------------------------------------------
UPDATE profile_sections SET title='Mengenal MIN 6 Jember', body='MIN 6 Jember adalah Madrasah Ibtidaiyah Negeri yang berada di Tanggul Wetan, Kecamatan Tanggul, Kabupaten Jember. Madrasah ini berkembang dari lembaga pendidikan Islam masyarakat dan terus memperkuat pembelajaran, pembiasaan keagamaan, karakter, serta pengembangan potensi peserta didik.', updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/hero_welcome.jpg' LIMIT 1) WHERE section_key='about';
UPDATE profile_sections SET title='Visi', body='Berakhlaqul Karimah dan Berprestasi.

Visi ini menjadi arah utama dalam membangun budaya madrasah: akhlak yang baik tumbuh melalui pembiasaan sehari-hari, sedangkan prestasi dikembangkan melalui pembelajaran, kegiatan pengembangan diri, serta kesempatan bagi peserta didik untuk mencoba dan berkarya.', updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/religious.jpg' LIMIT 1) WHERE section_key='vision';
UPDATE profile_sections SET title='Sejarah', body='MIN 6 Jember berawal dari MI Al Matlabul Ulum di bawah LP Ma''arif NU Kabupaten Jember. Berdasarkan arsip resmi madrasah, lembaga ini dinegerikan pada 1997 dan berubah menjadi MIN Tanggul Wetan. Perkembangan sarana berlangsung bertahap, termasuk pembangunan gedung baru pada 2008-2009. Sejak 2017, berdasarkan KMA RI Nomor 671 Tahun 2016, nama MIN Tanggul Wetan berubah menjadi MIN 6 Jember.', updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/ceremony.jpg' LIMIT 1) WHERE section_key='history';
UPDATE profile_sections SET title='Perjalanan Madrasah', body='1997 — MI Al Matlabul Ulum dinegerikan menjadi MIN Tanggul Wetan.
1999 — Mendapat rehab berat dan pembangunan gedung baru.
2007 — Pemerintah mengalokasikan dana pembelian tanah madrasah.
2008 — Pembangunan 6 ruang kelas belajar.
2009 — Penambahan 3 ruang kelas dan kegiatan belajar berpindah ke gedung baru.
2017 — Nama MIN Tanggul Wetan berubah menjadi MIN 6 Jember berdasarkan KMA RI Nomor 671 Tahun 2016.', updated_by=1, updated_at=NOW() WHERE section_key='timeline';
UPDATE profile_sections SET title='Sambutan Kepala Madrasah', body='Bismillahirrahmanirrahim.

Assalamu''alaikum warahmatullahi wabarakatuh.

Selamat datang di website MIN 6 Jember. Semoga website ini menjadi media informasi yang bermanfaat, memperkenalkan kegiatan dan layanan madrasah, serta memperkuat komunikasi dengan orang tua dan masyarakat.

Mari bersama-sama menumbuhkan generasi yang berakhlaqul karimah, berilmu, kreatif, dan berprestasi.

Wassalamu''alaikum warahmatullahi wabarakatuh.', updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/eko-iswanto.jpg' LIMIT 1) WHERE section_key='headmaster_message';
UPDATE profile_sections SET title='Identitas Madrasah', body='Nama: MIN 6 Jember
NPSN: 60715787
Status: Negeri
Akreditasi: A (berdasarkan profil resmi arsip)
Alamat: Jl. Urip Sumoharjo Gg. Legog, Tanggul Wetan, Kec. Tanggul, Kabupaten Jember
Telepon: 0336-443484
Email: mintanggulwetan@gmail.com', updated_by=1, updated_at=NOW() WHERE section_key='identity';
UPDATE profile_sections SET title='Lokasi', body='MIN 6 Jember berada di kawasan Tanggul Wetan, Kecamatan Tanggul, Kabupaten Jember, Jawa Timur. Informasi alamat dan petunjuk lokasi dapat diperbarui operator melalui Pengaturan Website bila titik Google Maps final sudah ditetapkan.', updated_by=1, updated_at=NOW(), primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/ceremony.jpg' LIMIT 1) WHERE section_key='location';

-- -----------------------------------------------------------------
-- PROGRAMS
-- -----------------------------------------------------------------
INSERT INTO programs (slug,name,category,summary,content,primary_media_id,display_order,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'pembiasaan-keagamaan','Pembiasaan Keagamaan','Keagamaan','Membentuk rutinitas ibadah dan adab melalui pembiasaan harian.','Pembiasaan mencakup Salat Dhuha, Asmaul Husna, membaca surat-surat pendek, doa sebelum belajar, dan Salat Zuhur berjamaah.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/religious.jpg' LIMIT 1),10,'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE slug='pembiasaan-keagamaan');
UPDATE programs SET name='Pembiasaan Keagamaan', category='Keagamaan', summary='Membentuk rutinitas ibadah dan adab melalui pembiasaan harian.', content='Pembiasaan mencakup Salat Dhuha, Asmaul Husna, membaca surat-surat pendek, doa sebelum belajar, dan Salat Zuhur berjamaah.', primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/religious.jpg' LIMIT 1), display_order=10, status='PUBLISHED', published_at=COALESCE(published_at,NOW()), updated_by=1, updated_at=NOW() WHERE slug='pembiasaan-keagamaan';
INSERT INTO programs (slug,name,category,summary,content,primary_media_id,display_order,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'yanbua','Pembelajaran Al-Qur''an Metode Yanbu''a','Keagamaan','Pendampingan membaca Al-Qur''an melalui metode Yanbu''a.','Program ini menjadi bagian dari penguatan kemampuan membaca Al-Qur''an dan pembiasaan religius peserta didik.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/yanbua.jpg' LIMIT 1),20,'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE slug='yanbua');
UPDATE programs SET name='Pembelajaran Al-Qur''an Metode Yanbu''a', category='Keagamaan', summary='Pendampingan membaca Al-Qur''an melalui metode Yanbu''a.', content='Program ini menjadi bagian dari penguatan kemampuan membaca Al-Qur''an dan pembiasaan religius peserta didik.', primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/yanbua.jpg' LIMIT 1), display_order=20, status='PUBLISHED', published_at=COALESCE(published_at,NOW()), updated_by=1, updated_at=NOW() WHERE slug='yanbua';
INSERT INTO programs (slug,name,category,summary,content,primary_media_id,display_order,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'pembelajaran-kelas','Pembelajaran di Kelas','Akademik','Pembelajaran aktif yang memberi ruang untuk memahami, mencoba, berdiskusi, dan berkarya.','Kegiatan kelas menjadi ruang utama pengembangan kompetensi akademik sekaligus karakter belajar peserta didik.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/classroom.jpg' LIMIT 1),30,'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE slug='pembelajaran-kelas');
UPDATE programs SET name='Pembelajaran di Kelas', category='Akademik', summary='Pembelajaran aktif yang memberi ruang untuk memahami, mencoba, berdiskusi, dan berkarya.', content='Kegiatan kelas menjadi ruang utama pengembangan kompetensi akademik sekaligus karakter belajar peserta didik.', primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/classroom.jpg' LIMIT 1), display_order=30, status='PUBLISHED', published_at=COALESCE(published_at,NOW()), updated_by=1, updated_at=NOW() WHERE slug='pembelajaran-kelas';
INSERT INTO programs (slug,name,category,summary,content,primary_media_id,display_order,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'budaya-disiplin','Budaya Disiplin dan Kebersamaan','Karakter','Disiplin dibangun dari kebiasaan datang, mengikuti kegiatan pagi, dan bertanggung jawab dalam keseharian.','Sambut siswa dan upacara bendera menjadi bagian dari budaya sekolah yang menumbuhkan kedisiplinan dan kebersamaan.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/ceremony.jpg' LIMIT 1),40,'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE slug='budaya-disiplin');
UPDATE programs SET name='Budaya Disiplin dan Kebersamaan', category='Karakter', summary='Disiplin dibangun dari kebiasaan datang, mengikuti kegiatan pagi, dan bertanggung jawab dalam keseharian.', content='Sambut siswa dan upacara bendera menjadi bagian dari budaya sekolah yang menumbuhkan kedisiplinan dan kebersamaan.', primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/ceremony.jpg' LIMIT 1), display_order=40, status='PUBLISHED', published_at=COALESCE(published_at,NOW()), updated_by=1, updated_at=NOW() WHERE slug='budaya-disiplin';
INSERT INTO programs (slug,name,category,summary,content,primary_media_id,display_order,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'ekstrakurikuler','Ekstrakurikuler dan Pengembangan Diri','Pengembangan Diri','Pilihan kegiatan untuk mengembangkan kepemimpinan, bahasa, olahraga, seni, dan minat peserta didik.','Pilihan dalam PDF sumber mencakup Pramuka, Bola Voli, Bahasa Inggris, pidato Bahasa Indonesia/Arab, puisi, pencak silat, mewarnai, Tahfidz, Tilawah, badminton, catur, tenis meja, menyanyi, hadrah, tari, kaligrafi, serta bidang akademik IPA dan Matematika.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/extracurricular.jpg' LIMIT 1),50,'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE slug='ekstrakurikuler');
UPDATE programs SET name='Ekstrakurikuler dan Pengembangan Diri', category='Pengembangan Diri', summary='Pilihan kegiatan untuk mengembangkan kepemimpinan, bahasa, olahraga, seni, dan minat peserta didik.', content='Pilihan dalam PDF sumber mencakup Pramuka, Bola Voli, Bahasa Inggris, pidato Bahasa Indonesia/Arab, puisi, pencak silat, mewarnai, Tahfidz, Tilawah, badminton, catur, tenis meja, menyanyi, hadrah, tari, kaligrafi, serta bidang akademik IPA dan Matematika.', primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/extracurricular.jpg' LIMIT 1), display_order=50, status='PUBLISHED', published_at=COALESCE(published_at,NOW()), updated_by=1, updated_at=NOW() WHERE slug='ekstrakurikuler';
INSERT INTO programs (slug,name,category,summary,content,primary_media_id,display_order,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'prestasi-dan-kreativitas','Prestasi dan Kreativitas','Prestasi','Memberi ruang bagi peserta didik untuk berani tampil, berkompetisi, dan mengembangkan potensi.','Prestasi dipandang sebagai hasil proses belajar dan pengalaman; operator dapat memperbarui capaian resmi melalui modul Prestasi.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/achievement.jpg' LIMIT 1),60,'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE slug='prestasi-dan-kreativitas');
UPDATE programs SET name='Prestasi dan Kreativitas', category='Prestasi', summary='Memberi ruang bagi peserta didik untuk berani tampil, berkompetisi, dan mengembangkan potensi.', content='Prestasi dipandang sebagai hasil proses belajar dan pengalaman; operator dapat memperbarui capaian resmi melalui modul Prestasi.', primary_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/achievement.jpg' LIMIT 1), display_order=60, status='PUBLISHED', published_at=COALESCE(published_at,NOW()), updated_by=1, updated_at=NOW() WHERE slug='prestasi-dan-kreativitas';

-- -----------------------------------------------------------------
-- GTK FROM PDF SOURCE
-- -----------------------------------------------------------------
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Eko Iswanto',NULL,'S.Pd., M.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/eko-iswanto.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',10,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Eko Iswanto');
UPDATE gtk SET front_title=NULL, back_title='S.Pd., M.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/eko-iswanto.jpg' LIMIT 1), display_order=10, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Eko Iswanto';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Ishaq Kholilur Rohman',NULL,'S.Pd., M.M.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/ishaq-kholilur-rohman.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',20,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Ishaq Kholilur Rohman');
UPDATE gtk SET front_title=NULL, back_title='S.Pd., M.M.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/ishaq-kholilur-rohman.jpg' LIMIT 1), display_order=20, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Ishaq Kholilur Rohman';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Siti Asrofah',NULL,'S.Pd.I.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/siti-asrofah.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',30,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Siti Asrofah');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.I.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/siti-asrofah.jpg' LIMIT 1), display_order=30, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Siti Asrofah';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'M. Zayyinul Furqon',NULL,'S.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/m-zayyinul-furqon.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',40,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='M. Zayyinul Furqon');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/m-zayyinul-furqon.jpg' LIMIT 1), display_order=40, is_active=1, updated_by=1, updated_at=NOW() WHERE name='M. Zayyinul Furqon';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Syaifudin Zuhri',NULL,'S.Pd.I., M.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/syaifudin-zuhri.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',50,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Syaifudin Zuhri');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.I., M.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/syaifudin-zuhri.jpg' LIMIT 1), display_order=50, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Syaifudin Zuhri';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Supangat',NULL,'A.Ma.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/supangat.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',60,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Supangat');
UPDATE gtk SET front_title=NULL, back_title='A.Ma.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/supangat.jpg' LIMIT 1), display_order=60, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Supangat';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Abdul Hamid',NULL,NULL,(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/abdul-hamid.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',70,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Abdul Hamid');
UPDATE gtk SET front_title=NULL, back_title=NULL, photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/abdul-hamid.jpg' LIMIT 1), display_order=70, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Abdul Hamid';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Agus Kiki Susanto',NULL,'S.Pd.I.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/agus-kiki-susanto.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',80,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Agus Kiki Susanto');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.I.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/agus-kiki-susanto.jpg' LIMIT 1), display_order=80, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Agus Kiki Susanto';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Isnainul Arifin',NULL,'S.Pd.I.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/isnainul-arifin.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',90,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Isnainul Arifin');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.I.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/isnainul-arifin.jpg' LIMIT 1), display_order=90, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Isnainul Arifin';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Fitriyani Purwanti',NULL,'S.Pd.I.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/fitriyani-purwanti.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',100,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Fitriyani Purwanti');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.I.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/fitriyani-purwanti.jpg' LIMIT 1), display_order=100, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Fitriyani Purwanti';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Sofwana',NULL,'S.Ag., M.M.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/sofwana.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',110,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Sofwana');
UPDATE gtk SET front_title=NULL, back_title='S.Ag., M.M.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/sofwana.jpg' LIMIT 1), display_order=110, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Sofwana';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Nur Hayati',NULL,'S.Pd.I.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/nur-hayati.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',120,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Nur Hayati');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.I.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/nur-hayati.jpg' LIMIT 1), display_order=120, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Nur Hayati';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Yusnia Khoirunnisa',NULL,'S.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/yusnia-khoirunnisa.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',130,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Yusnia Khoirunnisa');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/yusnia-khoirunnisa.jpg' LIMIT 1), display_order=130, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Yusnia Khoirunnisa';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Risya Umami Mu’ad',NULL,'S.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/risya-umami-muad.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',140,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Risya Umami Mu’ad');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/risya-umami-muad.jpg' LIMIT 1), display_order=140, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Risya Umami Mu’ad';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Ribut Setianingsih',NULL,'S.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/ribut-setianingsih.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',150,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Ribut Setianingsih');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/ribut-setianingsih.jpg' LIMIT 1), display_order=150, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Ribut Setianingsih';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Naely Hanik Rz',NULL,'S.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/naely-hanik-rz.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',160,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Naely Hanik Rz');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/naely-hanik-rz.jpg' LIMIT 1), display_order=160, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Naely Hanik Rz';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Mamik Nurhakim',NULL,'S.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/mamik-nurhakim.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',170,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Mamik Nurhakim');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/mamik-nurhakim.jpg' LIMIT 1), display_order=170, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Mamik Nurhakim';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Kholifah',NULL,'S.Pd.I.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/kholifah.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',180,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Kholifah');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.I.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/kholifah.jpg' LIMIT 1), display_order=180, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Kholifah';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Pangestika Wisnu Murti',NULL,'S.S.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/pangestika-wisnu-murti.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',190,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Pangestika Wisnu Murti');
UPDATE gtk SET front_title=NULL, back_title='S.S.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/pangestika-wisnu-murti.jpg' LIMIT 1), display_order=190, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Pangestika Wisnu Murti';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Ari Prasetyaningtias',NULL,'S.Pd.I.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/ari-prasetyaningtias.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',200,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Ari Prasetyaningtias');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.I.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/ari-prasetyaningtias.jpg' LIMIT 1), display_order=200, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Ari Prasetyaningtias';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Susiati',NULL,'S.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/susiati.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',210,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Susiati');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/susiati.jpg' LIMIT 1), display_order=210, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Susiati';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Lutfi Handayani',NULL,'S.Pd.I.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/lutfi-handayani.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',220,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Lutfi Handayani');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.I.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/lutfi-handayani.jpg' LIMIT 1), display_order=220, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Lutfi Handayani';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Badruttamam',NULL,'S.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/badruttamam.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',230,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Badruttamam');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/badruttamam.jpg' LIMIT 1), display_order=230, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Badruttamam';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Dodik Agung Dermawan',NULL,'S.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/dodik-agung-dermawan.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',240,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Dodik Agung Dermawan');
UPDATE gtk SET front_title=NULL, back_title='S.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/dodik-agung-dermawan.jpg' LIMIT 1), display_order=240, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Dodik Agung Dermawan';
INSERT INTO gtk (name,front_title,back_title,photo_media_id,short_bio,display_order,is_active,created_by,updated_by,created_at,updated_at)
SELECT 'Muhammad Ismail Wahyuda',NULL,'M.Pd.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/muhammad-ismail-wahyuda.jpg' LIMIT 1),'Data awal dari PDF profil MIN 6 Jember. Foto dapat diganti operator dengan foto resmi beresolusi lebih tinggi.',250,1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM gtk WHERE name='Muhammad Ismail Wahyuda');
UPDATE gtk SET front_title=NULL, back_title='M.Pd.', photo_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/muhammad-ismail-wahyuda.jpg' LIMIT 1), display_order=250, is_active=1, updated_by=1, updated_at=NOW() WHERE name='Muhammad Ismail Wahyuda';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,NULL,10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='HEADMASTER' WHERE g.name='Eko Iswanto' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,NULL,10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='PKM_CURRICULUM' WHERE g.name='Ishaq Kholilur Rohman' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 6A',20,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Ishaq Kholilur Rohman' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 6A', a.display_order=20 WHERE g.name='Ishaq Kholilur Rohman' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,NULL,10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='PKM_STUDENT' WHERE g.name='Siti Asrofah' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 5B',20,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Siti Asrofah' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 5B', a.display_order=20 WHERE g.name='Siti Asrofah' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,NULL,10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='PKM_INFRASTRUCTURE' WHERE g.name='M. Zayyinul Furqon' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 6B',20,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='M. Zayyinul Furqon' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 6B', a.display_order=20 WHERE g.name='M. Zayyinul Furqon' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,NULL,10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='PKM_PUBLIC_RELATIONS' WHERE g.name='Syaifudin Zuhri' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Pendidikan Agama Islam',20,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='SUBJECT_TEACHER' WHERE g.name='Syaifudin Zuhri' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Pendidikan Agama Islam', a.display_order=20 WHERE g.name='Syaifudin Zuhri' AND r.role_key='SUBJECT_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Tata Usaha · Anggota PKM Sarpras',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='ADMIN_STAFF' WHERE g.name='Supangat' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Tata Usaha · Anggota PKM Sarpras', a.display_order=10 WHERE g.name='Supangat' AND r.role_key='ADMIN_STAFF';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Tata Usaha · Anggota PKM Sarpras',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='ADMIN_STAFF' WHERE g.name='Abdul Hamid' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Tata Usaha · Anggota PKM Sarpras', a.display_order=10 WHERE g.name='Abdul Hamid' AND r.role_key='ADMIN_STAFF';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Tata Usaha · Anggota PKM Sarpras',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='ADMIN_STAFF' WHERE g.name='Agus Kiki Susanto' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Tata Usaha · Anggota PKM Sarpras', a.display_order=10 WHERE g.name='Agus Kiki Susanto' AND r.role_key='ADMIN_STAFF';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Tata Usaha · Anggota PKM Sarpras',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='ADMIN_STAFF' WHERE g.name='Isnainul Arifin' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Tata Usaha · Anggota PKM Sarpras', a.display_order=10 WHERE g.name='Isnainul Arifin' AND r.role_key='ADMIN_STAFF';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 1A',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Fitriyani Purwanti' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 1A', a.display_order=10 WHERE g.name='Fitriyani Purwanti' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 1B',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Sofwana' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 1B', a.display_order=10 WHERE g.name='Sofwana' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 1C',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Nur Hayati' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 1C', a.display_order=10 WHERE g.name='Nur Hayati' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 2A',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Yusnia Khoirunnisa' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 2A', a.display_order=10 WHERE g.name='Yusnia Khoirunnisa' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 2B',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Risya Umami Mu’ad' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 2B', a.display_order=10 WHERE g.name='Risya Umami Mu’ad' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 2C',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Ribut Setianingsih' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 2C', a.display_order=10 WHERE g.name='Ribut Setianingsih' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 3A',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Naely Hanik Rz' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 3A', a.display_order=10 WHERE g.name='Naely Hanik Rz' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 3B',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Mamik Nurhakim' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 3B', a.display_order=10 WHERE g.name='Mamik Nurhakim' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 4A',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Kholifah' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 4A', a.display_order=10 WHERE g.name='Kholifah' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 4B',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Pangestika Wisnu Murti' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 4B', a.display_order=10 WHERE g.name='Pangestika Wisnu Murti' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Bahasa Jawa',20,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='SUBJECT_TEACHER' WHERE g.name='Pangestika Wisnu Murti' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Bahasa Jawa', a.display_order=20 WHERE g.name='Pangestika Wisnu Murti' AND r.role_key='SUBJECT_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 4C',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Ari Prasetyaningtias' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 4C', a.display_order=10 WHERE g.name='Ari Prasetyaningtias' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Kelas 5A',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='CLASS_TEACHER' WHERE g.name='Susiati' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Kelas 5A', a.display_order=10 WHERE g.name='Susiati' AND r.role_key='CLASS_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Pendidikan Agama Islam',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='SUBJECT_TEACHER' WHERE g.name='Lutfi Handayani' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Pendidikan Agama Islam', a.display_order=10 WHERE g.name='Lutfi Handayani' AND r.role_key='SUBJECT_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru PJOK',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='SUBJECT_TEACHER' WHERE g.name='Badruttamam' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru PJOK', a.display_order=10 WHERE g.name='Badruttamam' AND r.role_key='SUBJECT_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru PJOK',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='SUBJECT_TEACHER' WHERE g.name='Dodik Agung Dermawan' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru PJOK', a.display_order=10 WHERE g.name='Dodik Agung Dermawan' AND r.role_key='SUBJECT_TEACHER';
INSERT INTO gtk_role_assignments (gtk_id,gtk_role_id,role_label_override,display_order,created_at)
SELECT g.id,r.id,'Guru Bahasa Inggris',10,NOW() FROM gtk g JOIN gtk_roles r ON r.role_key='SUBJECT_TEACHER' WHERE g.name='Muhammad Ismail Wahyuda' AND NOT EXISTS (SELECT 1 FROM gtk_role_assignments a WHERE a.gtk_id=g.id AND a.gtk_role_id=r.id);
UPDATE gtk_role_assignments a JOIN gtk g ON g.id=a.gtk_id JOIN gtk_roles r ON r.id=a.gtk_role_id SET a.role_label_override='Guru Bahasa Inggris', a.display_order=10 WHERE g.name='Muhammad Ismail Wahyuda' AND r.role_key='SUBJECT_TEACHER';

-- -----------------------------------------------------------------
-- NEWS
-- -----------------------------------------------------------------
INSERT INTO news (slug,title,summary,content,primary_media_id,status,published_at,meta_title,meta_description,og_media_id,created_by,updated_by,created_at,updated_at)
SELECT 'min-6-jember-memperingati-maulid-nabi-rasulullah-panutanku-surga-tujuanku','MIN 6 Jember Memperingati Maulid Nabi dengan Tema "Rasulullah Panutanku, Surga Tujuanku"','MIN 6 Jember menggelar peringatan Maulid Nabi Muhammad SAW pada September 2025 dengan suasana khidmat dan semarak.','Berita ini diringkas dari website resmi/arsip MIN 6 Jember. Kegiatan peringatan Maulid Nabi menjadi bagian dari penguatan keteladanan Rasulullah dan pembiasaan nilai keagamaan di lingkungan madrasah.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/religious.jpg' LIMIT 1),'PUBLISHED','2025-09-19 15:51:00','MIN 6 Jember Memperingati Maulid Nabi dengan Tema "Rasulullah Panutanku, Surga Tujuanku"','MIN 6 Jember menggelar peringatan Maulid Nabi Muhammad SAW pada September 2025 dengan suasana khidmat dan semarak.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/religious.jpg' LIMIT 1),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM news WHERE slug='min-6-jember-memperingati-maulid-nabi-rasulullah-panutanku-surga-tujuanku');
INSERT INTO news (slug,title,summary,content,primary_media_id,status,published_at,meta_title,meta_description,og_media_id,created_by,updated_by,created_at,updated_at)
SELECT 'kepala-min-6-jember-siap-bertransformasi-menuju-indonesia-emas-2045','Kepala MIN 6 Jember Siap Bertransformasi Menuju Indonesia Emas 2045','Arsip berita resmi madrasah mencatat komitmen transformasi dan penguatan mutu menuju Indonesia Emas 2045.','Konten ringkas ini disiapkan dari arsip berita website resmi MIN 6 Jember. Operator dapat memperbarui isi lengkap, dokumentasi, dan metadata sebelum website produksi.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/eko-iswanto.jpg' LIMIT 1),'PUBLISHED','2024-02-06 22:41:00','Kepala MIN 6 Jember Siap Bertransformasi Menuju Indonesia Emas 2045','Arsip berita resmi madrasah mencatat komitmen transformasi dan penguatan mutu menuju Indonesia Emas 2045.',(SELECT id FROM media WHERE relative_path='uploads/demo/gtk/eko-iswanto.jpg' LIMIT 1),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM news WHERE slug='kepala-min-6-jember-siap-bertransformasi-menuju-indonesia-emas-2045');
INSERT INTO news (slug,title,summary,content,primary_media_id,status,published_at,meta_title,meta_description,og_media_id,created_by,updated_by,created_at,updated_at)
SELECT 'demo-pembiasaan-pagi-membangun-disiplin-dan-karakter','[DEMO] Pembiasaan Pagi: Membangun Disiplin dan Karakter','Konten contoh untuk menampilkan layout berita menggunakan dokumentasi sambut siswa dan kegiatan pagi.','Konten DEMO untuk kebutuhan pratinjau website. Ganti dengan berita resmi sebelum website dipublikasikan. Pembiasaan pagi di MIN 6 Jember dalam PDF sumber mencakup sambut siswa, upacara Senin, dan kegiatan keagamaan harian.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/hero_welcome.jpg' LIMIT 1),'PUBLISHED','2026-02-05 08:00:00','Pembiasaan Pagi: Membangun Disiplin dan Karakter','Konten contoh untuk menampilkan layout berita menggunakan dokumentasi sambut siswa dan kegiatan pagi.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/hero_welcome.jpg' LIMIT 1),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM news WHERE slug='demo-pembiasaan-pagi-membangun-disiplin-dan-karakter');

-- -----------------------------------------------------------------
-- EVENTS (DEMO)
-- -----------------------------------------------------------------
INSERT INTO events (slug,title,summary,description,location,start_at,end_at,primary_media_id,status,created_by,updated_by,created_at,updated_at)
SELECT 'demo-khatmil-quran-dan-doa-bersama','[DEMO] Khatmil Qur''an dan Doa Bersama','Agenda contoh untuk menguji tampilan agenda publik.','Konten DEMO. Jadwal dan detail wajib diganti operator sebelum produksi.','MIN 6 Jember','2026-10-16 07:00:00','2026-10-16 09:00:00',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/yanbua.jpg' LIMIT 1),'PUBLISHED',1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM events WHERE slug='demo-khatmil-quran-dan-doa-bersama');
INSERT INTO events (slug,title,summary,description,location,start_at,end_at,primary_media_id,status,created_by,updated_by,created_at,updated_at)
SELECT 'demo-gelar-karya-dan-pentas-siswa','[DEMO] Gelar Karya dan Pentas Siswa','Agenda contoh untuk menampilkan kegiatan seni, kreativitas, dan ekstrakurikuler.','Konten DEMO. Jadwal dan detail wajib diganti operator sebelum produksi.','Halaman MIN 6 Jember','2026-11-07 08:00:00','2026-11-07 11:30:00',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/extracurricular.jpg' LIMIT 1),'PUBLISHED',1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM events WHERE slug='demo-gelar-karya-dan-pentas-siswa');
INSERT INTO events (slug,title,summary,description,location,start_at,end_at,primary_media_id,status,created_by,updated_by,created_at,updated_at)
SELECT 'demo-pertemuan-wali-murid','[DEMO] Pertemuan Wali Murid','Agenda contoh komunikasi madrasah bersama orang tua/wali.','Konten DEMO. Jadwal dan detail wajib diganti operator sebelum produksi.','MIN 6 Jember','2026-11-21 08:00:00','2026-11-21 10:00:00',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/classroom.jpg' LIMIT 1),'PUBLISHED',1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM events WHERE slug='demo-pertemuan-wali-murid');

-- -----------------------------------------------------------------
-- ACHIEVEMENTS (DEMO)
-- -----------------------------------------------------------------
INSERT INTO achievements (slug,title,participant_name,field_name,award,level,organizer,achievement_date,summary,content,primary_media_id,status,published_at,meta_title,meta_description,og_media_id,created_by,updated_by,created_at,updated_at)
SELECT 'demo-prestasi-akademik-peserta-didik','[DEMO] Prestasi Akademik Peserta Didik','Peserta Didik MIN 6 Jember','Akademik','Dokumentasi Prestasi','Madrasah','MIN 6 Jember','2026-02-05','Konten contoh untuk menampilkan modul Prestasi sampai data capaian resmi dimasukkan operator.','Konten contoh untuk menampilkan modul Prestasi sampai data capaian resmi dimasukkan operator.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/achievement.jpg' LIMIT 1),'PUBLISHED',NOW(),'Prestasi Akademik Peserta Didik','Konten contoh untuk menampilkan modul Prestasi sampai data capaian resmi dimasukkan operator.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/achievement.jpg' LIMIT 1),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM achievements WHERE slug='demo-prestasi-akademik-peserta-didik');
INSERT INTO achievements (slug,title,participant_name,field_name,award,level,organizer,achievement_date,summary,content,primary_media_id,status,published_at,meta_title,meta_description,og_media_id,created_by,updated_by,created_at,updated_at)
SELECT 'demo-prestasi-seni-dan-keagamaan','[DEMO] Prestasi Seni dan Keagamaan','Peserta Didik MIN 6 Jember','Tahfidz, Tilawah dan Seni','Dokumentasi Prestasi','Madrasah','MIN 6 Jember','2026-02-05','Konten contoh untuk menampilkan ragam potensi peserta didik pada bidang seni dan keagamaan.','Konten contoh untuk menampilkan ragam potensi peserta didik pada bidang seni dan keagamaan.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/extracurricular.jpg' LIMIT 1),'PUBLISHED',NOW(),'Prestasi Seni dan Keagamaan','Konten contoh untuk menampilkan ragam potensi peserta didik pada bidang seni dan keagamaan.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/extracurricular.jpg' LIMIT 1),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM achievements WHERE slug='demo-prestasi-seni-dan-keagamaan');
INSERT INTO achievements (slug,title,participant_name,field_name,award,level,organizer,achievement_date,summary,content,primary_media_id,status,published_at,meta_title,meta_description,og_media_id,created_by,updated_by,created_at,updated_at)
SELECT 'demo-prestasi-olahraga-dan-ekstrakurikuler','[DEMO] Prestasi Olahraga dan Ekstrakurikuler','Peserta Didik MIN 6 Jember','Olahraga dan Ekstrakurikuler','Dokumentasi Prestasi','Madrasah','MIN 6 Jember','2026-02-05','Konten contoh untuk menampilkan capaian kegiatan pengembangan diri. Ganti dengan data prestasi resmi sebelum produksi.','Konten contoh untuk menampilkan capaian kegiatan pengembangan diri. Ganti dengan data prestasi resmi sebelum produksi.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/ceremony.jpg' LIMIT 1),'PUBLISHED',NOW(),'Prestasi Olahraga dan Ekstrakurikuler','Konten contoh untuk menampilkan capaian kegiatan pengembangan diri. Ganti dengan data prestasi resmi sebelum produksi.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/ceremony.jpg' LIMIT 1),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM achievements WHERE slug='demo-prestasi-olahraga-dan-ekstrakurikuler');

-- -----------------------------------------------------------------
-- GALLERIES
-- -----------------------------------------------------------------
INSERT INTO galleries (slug,title,gallery_date,description,cover_media_id,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'sambut-siswa-setiap-pagi','Sambut Siswa Setiap Pagi','2026-02-05','Pembiasaan menyambut siswa sebagai bagian dari budaya keseharian madrasah.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/hero_welcome.jpg' LIMIT 1),'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM galleries WHERE slug='sambut-siswa-setiap-pagi');
INSERT INTO gallery_items (gallery_id,media_id,caption,display_order,created_at)
SELECT g.id,m.id,'Pembiasaan menyambut siswa sebagai bagian dari budaya keseharian madrasah.',10,NOW() FROM galleries g JOIN media m ON m.relative_path='uploads/demo/activities/hero_welcome.jpg' WHERE g.slug='sambut-siswa-setiap-pagi' AND NOT EXISTS (SELECT 1 FROM gallery_items gi WHERE gi.gallery_id=g.id AND gi.media_id=m.id);
INSERT INTO galleries (slug,title,gallery_date,description,cover_media_id,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'upacara-bendera-senin-pagi','Upacara Bendera Senin Pagi','2026-02-05','Dokumentasi pembiasaan upacara bendera di halaman madrasah.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/ceremony.jpg' LIMIT 1),'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM galleries WHERE slug='upacara-bendera-senin-pagi');
INSERT INTO gallery_items (gallery_id,media_id,caption,display_order,created_at)
SELECT g.id,m.id,'Dokumentasi pembiasaan upacara bendera di halaman madrasah.',10,NOW() FROM galleries g JOIN media m ON m.relative_path='uploads/demo/activities/ceremony.jpg' WHERE g.slug='upacara-bendera-senin-pagi' AND NOT EXISTS (SELECT 1 FROM gallery_items gi WHERE gi.gallery_id=g.id AND gi.media_id=m.id);
INSERT INTO galleries (slug,title,gallery_date,description,cover_media_id,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'pembiasaan-keagamaan-harian','Pembiasaan Keagamaan Harian','2026-02-05','Salat Dhuha, Asmaul Husna, surat-surat pendek, doa sebelum belajar, dan Salat Zuhur berjamaah.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/religious.jpg' LIMIT 1),'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM galleries WHERE slug='pembiasaan-keagamaan-harian');
INSERT INTO gallery_items (gallery_id,media_id,caption,display_order,created_at)
SELECT g.id,m.id,'Salat Dhuha, Asmaul Husna, surat-surat pendek, doa sebelum belajar, dan Salat Zuhur berjamaah.',10,NOW() FROM galleries g JOIN media m ON m.relative_path='uploads/demo/activities/religious.jpg' WHERE g.slug='pembiasaan-keagamaan-harian' AND NOT EXISTS (SELECT 1 FROM gallery_items gi WHERE gi.gallery_id=g.id AND gi.media_id=m.id);
INSERT INTO galleries (slug,title,gallery_date,description,cover_media_id,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'pembelajaran-yanbua','Pembelajaran Al-Qur''an Metode Yanbu''a','2026-02-05','Dokumentasi pembelajaran Al-Qur''an metode Yanbu''a.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/yanbua.jpg' LIMIT 1),'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM galleries WHERE slug='pembelajaran-yanbua');
INSERT INTO gallery_items (gallery_id,media_id,caption,display_order,created_at)
SELECT g.id,m.id,'Dokumentasi pembelajaran Al-Qur''an metode Yanbu''a.',10,NOW() FROM galleries g JOIN media m ON m.relative_path='uploads/demo/activities/yanbua.jpg' WHERE g.slug='pembelajaran-yanbua' AND NOT EXISTS (SELECT 1 FROM gallery_items gi WHERE gi.gallery_id=g.id AND gi.media_id=m.id);
INSERT INTO galleries (slug,title,gallery_date,description,cover_media_id,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'pembelajaran-di-kelas','Pembelajaran di Kelas','2026-02-05','Potret kegiatan belajar peserta didik di kelas.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/classroom.jpg' LIMIT 1),'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM galleries WHERE slug='pembelajaran-di-kelas');
INSERT INTO gallery_items (gallery_id,media_id,caption,display_order,created_at)
SELECT g.id,m.id,'Potret kegiatan belajar peserta didik di kelas.',10,NOW() FROM galleries g JOIN media m ON m.relative_path='uploads/demo/activities/classroom.jpg' WHERE g.slug='pembelajaran-di-kelas' AND NOT EXISTS (SELECT 1 FROM gallery_items gi WHERE gi.gallery_id=g.id AND gi.media_id=m.id);
INSERT INTO galleries (slug,title,gallery_date,description,cover_media_id,status,published_at,created_by,updated_by,created_at,updated_at)
SELECT 'ekstrakurikuler-dan-prestasi','Ekstrakurikuler dan Prestasi','2026-02-05','Dokumentasi kegiatan pengembangan diri, kompetisi, dan prestasi peserta didik.',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/extracurricular.jpg' LIMIT 1),'PUBLISHED',NOW(),1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM galleries WHERE slug='ekstrakurikuler-dan-prestasi');
INSERT INTO gallery_items (gallery_id,media_id,caption,display_order,created_at)
SELECT g.id,m.id,'Dokumentasi kegiatan pengembangan diri, kompetisi, dan prestasi peserta didik.',10,NOW() FROM galleries g JOIN media m ON m.relative_path='uploads/demo/activities/extracurricular.jpg' WHERE g.slug='ekstrakurikuler-dan-prestasi' AND NOT EXISTS (SELECT 1 FROM gallery_items gi WHERE gi.gallery_id=g.id AND gi.media_id=m.id);

-- -----------------------------------------------------------------
-- SPMB 2026/2027 FROM PDF POSTER
-- QR decoded from poster: https://get-qr.com/vRoUhu
-- -----------------------------------------------------------------
INSERT INTO spmb_periods (academic_year,title,summary,content,start_date,end_date,registration_url,qr_media_id,brochure_media_id,contact_name,contact_phone,status,is_current,created_by,updated_by,created_at,updated_at)
SELECT '2026/2027','Penerimaan Murid Baru Madrasah 2026/2027','Pendaftaran Januari - Juli 2026. Informasi bersumber dari poster resmi pada PDF internal MIN 6 Jember.','Penerimaan Murid Baru Madrasah MIN 6 Jember Tahun Ajaran 2026/2027. Program unggulan dan pengembangan diri dalam poster meliputi pembelajaran Al-Qur''an Yanbu''a, Pramuka, olahraga, bahasa, pidato, seni, Tahfidz, Tilawah, Hadrah, Tari, Kaligrafi, serta bidang akademik IPA dan Matematika.','2026-01-01','2026-07-31','https://get-qr.com/vRoUhu',(SELECT id FROM media WHERE relative_path='uploads/demo/activities/spmb_qr.jpg' LIMIT 1),(SELECT id FROM media WHERE relative_path='uploads/demo/activities/spmb_poster.jpg' LIMIT 1),'Saifudin / Dodik Agung','085233338519 / 082231007143','PUBLISHED',1,1,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM spmb_periods WHERE academic_year='2026/2027');
UPDATE spmb_periods SET is_current=0 WHERE academic_year<>'2026/2027';
UPDATE spmb_periods SET status='PUBLISHED', is_current=1, registration_url='https://get-qr.com/vRoUhu', qr_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/spmb_qr.jpg' LIMIT 1), brochure_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/spmb_2026_2027_poster.pdf' LIMIT 1), contact_name='Saifudin / Dodik Agung', contact_phone='085233338519 / 082231007143', updated_by=1, updated_at=NOW() WHERE academic_year='2026/2027';
INSERT INTO spmb_requirements (spmb_period_id,requirement_text,display_order)
SELECT s.id,'Mengisi formulir pendaftaran.',10 FROM spmb_periods s WHERE s.academic_year='2026/2027' AND NOT EXISTS (SELECT 1 FROM spmb_requirements r WHERE r.spmb_period_id=s.id AND r.requirement_text='Mengisi formulir pendaftaran.');
INSERT INTO spmb_requirements (spmb_period_id,requirement_text,display_order)
SELECT s.id,'Fotokopi Akta Kelahiran dan Kartu Keluarga (KK).',11 FROM spmb_periods s WHERE s.academic_year='2026/2027' AND NOT EXISTS (SELECT 1 FROM spmb_requirements r WHERE r.spmb_period_id=s.id AND r.requirement_text='Fotokopi Akta Kelahiran dan Kartu Keluarga (KK).');
INSERT INTO spmb_requirements (spmb_period_id,requirement_text,display_order)
SELECT s.id,'Pas foto ukuran 3x4 sebanyak 4 lembar.',12 FROM spmb_periods s WHERE s.academic_year='2026/2027' AND NOT EXISTS (SELECT 1 FROM spmb_requirements r WHERE r.spmb_period_id=s.id AND r.requirement_text='Pas foto ukuran 3x4 sebanyak 4 lembar.');
INSERT INTO spmb_requirements (spmb_period_id,requirement_text,display_order)
SELECT s.id,'Fotokopi rapor terakhir.',13 FROM spmb_periods s WHERE s.academic_year='2026/2027' AND NOT EXISTS (SELECT 1 FROM spmb_requirements r WHERE r.spmb_period_id=s.id AND r.requirement_text='Fotokopi rapor terakhir.');
INSERT INTO spmb_faq (spmb_period_id,question,answer,display_order)
SELECT s.id,'Kapan periode pendaftaran?','Poster sumber mencantumkan periode Januari sampai Juli 2026.',10 FROM spmb_periods s WHERE s.academic_year='2026/2027' AND NOT EXISTS (SELECT 1 FROM spmb_faq f WHERE f.spmb_period_id=s.id AND f.question='Kapan periode pendaftaran?');
INSERT INTO spmb_faq (spmb_period_id,question,answer,display_order)
SELECT s.id,'Bagaimana membuka formulir pendaftaran?','Gunakan QR/link pendaftaran yang tersedia pada halaman ini. Tautan QR pada poster mengarah ke https://get-qr.com/vRoUhu.',11 FROM spmb_periods s WHERE s.academic_year='2026/2027' AND NOT EXISTS (SELECT 1 FROM spmb_faq f WHERE f.spmb_period_id=s.id AND f.question='Bagaimana membuka formulir pendaftaran?');
INSERT INTO spmb_faq (spmb_period_id,question,answer,display_order)
SELECT s.id,'Siapa yang dapat dihubungi?','Kontak pada poster: Saifudin 085233338519 dan Dodik Agung 082231007143.',12 FROM spmb_periods s WHERE s.academic_year='2026/2027' AND NOT EXISTS (SELECT 1 FROM spmb_faq f WHERE f.spmb_period_id=s.id AND f.question='Siapa yang dapat dihubungi?');
INSERT INTO spmb_faq (spmb_period_id,question,answer,display_order)
SELECT s.id,'Dokumen apa yang perlu disiapkan?','Formulir pendaftaran, fotokopi akta kelahiran dan KK, pas foto 3x4 sebanyak 4 lembar, serta fotokopi rapor terakhir.',13 FROM spmb_periods s WHERE s.academic_year='2026/2027' AND NOT EXISTS (SELECT 1 FROM spmb_faq f WHERE f.spmb_period_id=s.id AND f.question='Dokumen apa yang perlu disiapkan?');

-- -----------------------------------------------------------------
-- INSTAGRAM MANUAL FALLBACK
-- -----------------------------------------------------------------
INSERT INTO instagram_posts (source,instagram_media_id,permalink,caption,media_type,media_url,thumbnail_url,local_media_id,published_at,is_fallback,is_visible,sort_order,fetched_at,created_at,updated_at)
SELECT 'MANUAL',NULL,'https://www.instagram.com/min6jember','Sambut siswa setiap pagi di MIN 6 Jember.','IMAGE',NULL,NULL,(SELECT id FROM media WHERE relative_path='uploads/demo/activities/hero_welcome.jpg' LIMIT 1),'2026-02-05 08:00:00',1,1,10,NULL,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM instagram_posts WHERE source='MANUAL' AND local_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/hero_welcome.jpg' LIMIT 1));
INSERT INTO instagram_posts (source,instagram_media_id,permalink,caption,media_type,media_url,thumbnail_url,local_media_id,published_at,is_fallback,is_visible,sort_order,fetched_at,created_at,updated_at)
SELECT 'MANUAL',NULL,'https://www.instagram.com/min6jember','Upacara bendera dan pembiasaan kedisiplinan.','IMAGE',NULL,NULL,(SELECT id FROM media WHERE relative_path='uploads/demo/activities/ceremony.jpg' LIMIT 1),'2026-02-05 08:00:00',1,1,20,NULL,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM instagram_posts WHERE source='MANUAL' AND local_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/ceremony.jpg' LIMIT 1));
INSERT INTO instagram_posts (source,instagram_media_id,permalink,caption,media_type,media_url,thumbnail_url,local_media_id,published_at,is_fallback,is_visible,sort_order,fetched_at,created_at,updated_at)
SELECT 'MANUAL',NULL,'https://www.instagram.com/min6jember','Pembiasaan keagamaan dalam keseharian madrasah.','IMAGE',NULL,NULL,(SELECT id FROM media WHERE relative_path='uploads/demo/activities/religious.jpg' LIMIT 1),'2026-02-05 08:00:00',1,1,30,NULL,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM instagram_posts WHERE source='MANUAL' AND local_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/religious.jpg' LIMIT 1));
INSERT INTO instagram_posts (source,instagram_media_id,permalink,caption,media_type,media_url,thumbnail_url,local_media_id,published_at,is_fallback,is_visible,sort_order,fetched_at,created_at,updated_at)
SELECT 'MANUAL',NULL,'https://www.instagram.com/min6jember','Pembelajaran Al-Qur''an metode Yanbu''a.','IMAGE',NULL,NULL,(SELECT id FROM media WHERE relative_path='uploads/demo/activities/yanbua.jpg' LIMIT 1),'2026-02-05 08:00:00',1,1,40,NULL,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM instagram_posts WHERE source='MANUAL' AND local_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/yanbua.jpg' LIMIT 1));
INSERT INTO instagram_posts (source,instagram_media_id,permalink,caption,media_type,media_url,thumbnail_url,local_media_id,published_at,is_fallback,is_visible,sort_order,fetched_at,created_at,updated_at)
SELECT 'MANUAL',NULL,'https://www.instagram.com/min6jember','Belajar bersama di kelas.','IMAGE',NULL,NULL,(SELECT id FROM media WHERE relative_path='uploads/demo/activities/classroom.jpg' LIMIT 1),'2026-02-05 08:00:00',1,1,50,NULL,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM instagram_posts WHERE source='MANUAL' AND local_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/classroom.jpg' LIMIT 1));
INSERT INTO instagram_posts (source,instagram_media_id,permalink,caption,media_type,media_url,thumbnail_url,local_media_id,published_at,is_fallback,is_visible,sort_order,fetched_at,created_at,updated_at)
SELECT 'MANUAL',NULL,'https://www.instagram.com/min6jember','Ekstrakurikuler, kebersamaan, dan prestasi.','IMAGE',NULL,NULL,(SELECT id FROM media WHERE relative_path='uploads/demo/activities/extracurricular.jpg' LIMIT 1),'2026-02-05 08:00:00',1,1,60,NULL,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM instagram_posts WHERE source='MANUAL' AND local_media_id=(SELECT id FROM media WHERE relative_path='uploads/demo/activities/extracurricular.jpg' LIMIT 1));

COMMIT;

-- END INITIAL CONTENT SEED