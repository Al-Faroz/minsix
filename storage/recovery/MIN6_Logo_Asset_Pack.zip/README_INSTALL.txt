MIN 6 JEMBER — LOGO ASSET PACK
================================

Cara paling mudah:
1. Tutup/abaikan file lama di:
   G:\xampp\htdocs\minsix\assets\brand\
2. Ekstrak ZIP ini ke:
   G:\xampp\htdocs\minsix\
3. Saat diminta, pilih Replace/Overwrite.

Struktur hasil:
assets/brand/
  min6-logo.png
  min6-logo-white.png
  min6-logo-256.png
  min6-logo-white-256.png
  min6-logo-ui.png
  min6-logo-white-ui.png
  favicon.ico
  favicon-16x16.png
  favicon-32x32.png
  apple-touch-icon.png
  android-chrome-192x192.png
  android-chrome-512x512.png

File utama yang saat ini dipakai source website:
- assets/brand/min6-logo.png
- assets/brand/min6-logo-white.png
- assets/brand/favicon-32x32.png

Setelah replace:
  cd G:\xampp\htdocs\minsix
  git status
  git add assets/brand
  git commit -m "Replace final MIN 6 Jember branding assets"
  git push

Kemudian refresh browser dengan Ctrl+F5.
